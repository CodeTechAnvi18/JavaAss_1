package com.ass;

import java.util.Scanner;

public class Question_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		int sub1,sub2,sub3;
		
		System.out.println("enter sub1 marks");
		sub1=sc.nextInt();
		
		System.out.println("enter sub2 marks");
		sub2=sc.nextInt();
		
		System.out.println("enter sub3 marks");
		sub3=sc.nextInt();
		
		float avgM=(sub1+sub2+sub3)/3.0f;
		
		System.out.println("Total Marks= "+avgM);
		
		if(avgM>=60 && 60<=avgM) {
			System.out.println("1st class");
		}else if(sub1>=40 && sub2>=40 && sub3>=40) {
			System.out.println("2nd class");
				
		}else {
			System.out.println("fail");
		}
		

	}

}
