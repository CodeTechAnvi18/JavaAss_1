package com.ass;

import java.util.Scanner;

public class Question_6 {

	public static void main(String[] args) {
		
		 Scanner sc = new Scanner(System.in);

	        System.out.print("Enter a number: ");
	        int n = sc.nextInt();

	        boolean isRange = !(n >= 10 && n <= 20);

	        if (isRange) {
	            System.out.println("The number is not between 10 and 20 ");
	        } else {
	            System.out.println("The number is between 10 and 20");
	        }

	}

}
