package com.ass;

import java.util.Scanner;

public class Question_4 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

        System.out.print("Are you a citizen? (true/false): ");
        boolean isCitizen = sc.nextBoolean();

        System.out.print("Enter your age: ");
        int age = sc.nextInt();

        boolean isEligible = isCitizen && (age >= 18);

        if (isEligible) {
            System.out.println("You are eligible to vote.");
        } else {
            System.out.println("You are not eligible to vote.");
        }
		
	}

}
