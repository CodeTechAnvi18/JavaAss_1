package com.ass;

import java.util.Scanner;

public class Question_7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter the temperature in °C: ");
        int temp = sc.nextInt();

        System.out.print("Is it raining? (true/false): ");
        boolean isRaining = sc.nextBoolean();

        boolean isSafe = (temp >= 20 && temp <= 30) && !isRaining;

        if (isSafe) {
            System.out.println("It's safe to go outside.");
        } else {
            System.out.println("It's not safe to go outside.");
        }

	}

}
