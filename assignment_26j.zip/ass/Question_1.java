package com.ass;

import java.util.Scanner;

public class Question_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the age: ");
		int age=sc.nextInt();
		
		System.out.println("enter the income: ");
		int income=sc.nextInt();
		
		if(age>=18 && age<=60 && income<=25000) {
			System.out.println("Person is Eligible for loan");
		}else {
			System.out.println("Person is not eligible for loan");
		}

	}

}
