package com.ass;

import java.util.Scanner;

public class Question_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Scanner sc = new Scanner(System.in);

	        System.out.print("Do you have a bachelor's degree or equivalent experience? (true/false): ");
	        boolean hasDegExp = sc.nextBoolean();

	        System.out.print("Do you have a clean criminal record? (true/false): ");
	        boolean hasCriminalRecord = sc.nextBoolean();

	        boolean isEligibleForJob = (hasDegExp) && (hasCriminalRecord);

	        if (isEligibleForJob) {
	            System.out.println("You are eligible for the job.");
	        } else {
	            System.out.println("You are not eligible for the job.");
	        }

	}

}
